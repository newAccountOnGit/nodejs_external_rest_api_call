
const https = require('https');
const express = require("express");
const app = express();
_EXTERNAL_URL = 'https://dummy.restapiexample.com/api/v1/employees';


function call() {
    https.get(_EXTERNAL_URL, (resp) => {
    let data = '';
    
    // A chunk of data has been recieved.
    resp.on('data', (chunk) => {
        data += chunk;
        console.log(data);
    });
    
    // The whole response has been received. Print out the result.
    resp.on('end', () => {
        console.log(JSON.stringify(data));
        return data;
       // console.log(JSON.stringify(data));
    });
    
    }).on("error", (err) => {
       
    console.log("Error: " + err.message);
    });
}

app.listen(5000, function() {
    console.log("node app  running on port 5000");
    call();
  })
