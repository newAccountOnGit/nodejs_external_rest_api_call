//*************************  External Rest API GET call using node-fetch  ****************************************************************//
// npm installnode-fetch@2 //

const express = require("express");
const app = express();
const fetch = require("node-fetch");


function callExternalApi() {
  let url = "https://dummy.restapiexample.com/api/v1/employees";
  fetch(url).then((res) => {
    res.json().then((res1) => {
      console.log(res1);
    })
  })
}

app.listen(3000, function() {
  console.log("node app  running on port 3000");
  callExternalApi();
})

//*****************************************************************************************//