//******************************   External Rest API GET call using axios   ******************************************************//
// npm install axios //
const axios = require('axios');
const express = require('express');
const app = express();


app.get('/getCall', async function(req,res) {
    axios.get('https://jsonplaceholder.typicode.com/posts/1').then(function(a){
        console.log(a);
        res.send(a.data);
        
    });
});


app.post('/postCall', (req, res) => {
        axios.post('https://reqres.in/api/users', {
        "name": "morpheus",
        "job": "leader"
      }).then(function(a){
        console.log(a);
        res.send(a.data);        
    });
})

app.listen(4000, function() {
    console.log("listen on port 4000");
})
//************************************************************************************//